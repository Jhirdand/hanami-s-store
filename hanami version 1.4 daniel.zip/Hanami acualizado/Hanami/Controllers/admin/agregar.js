function agregarCard() {
    // Crear elemento de tarjeta
    var card = document.createElement("div");
    card.className = "card";
    card.textContent = "Contenido de la tarjeta";
  
    // Agregar la tarjeta al contenedor
    var container = document.getElementById("container");
    container.appendChild(card);
  }
  
  function eliminarCard() {
    // Obtener el contenedor y la última tarjeta agregada
    var container = document.getElementById("container");
    var cards = container.getElementsByClassName("card");
    var lastCard = cards[cards.length - 1];
  
    // Eliminar la última tarjeta si existe
    if (lastCard) {
      container.removeChild(lastCard);
    }
  }