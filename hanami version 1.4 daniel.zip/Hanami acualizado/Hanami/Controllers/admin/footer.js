document.addEventListener('DOMContentLoaded', function() {
  const footer = document.getElementById('footer');
  footer.innerHTML = `
    <div class="footer-container bg-lightpink p-3">
      <div class="row justify-content-between align-items-center">
        <div class="col-12 col-md-6 text-center text-md-left">
          <span class="hanami-name">Hanami</span>
        </div>
        <div class="col-12 col-md-6 text-center text-md-right">
          <a href="https://www.instagram.com/accounts/login/" class="social-icon"><img src="../../Resources/images/instagram.png" alt="Instagram"></a>
          <a href="https://www.facebook.com/?stype=lo&deoia=1&jlou=AfcfebGvoLk84oSKmXjynEVAfvHo8p4dJ5Vfoq1BZfguZKePNpRa360HbbcZJnOBqp-1AjQR6948N9eb7RlKRu09zermptDnJfVgYYs2swueSw&smuh=32859&lh=Ac-VQJt15vLm_ShQN_s" class="social-icon"><img src="../../Resources/images/facebook.png" alt="Facebook"></a>
          <a href="https://about.x.com/en/who-we-are/brand-toolkit" class="social-icon"><img src="../../Resources/images/xtwiter.png" alt="X"></a>
        </div>
      </div>
    </div>
  `;
});